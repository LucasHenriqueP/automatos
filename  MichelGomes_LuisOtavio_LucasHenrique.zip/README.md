# :computer:Autômato Finito Não Determinístico- Linguagens Formais, Automatos e Computabilidade

Projeto de implementação de um [Autômato Finito Não Determinístico](https://en.wikipedia.org/wiki/Nondeterministic_finite_automaton) para a disciplina de Linguagens Formais, Automatos e Computabilidade.

## Como Executar 🚀

	$ python3 main.py [documento.txt] [entrada_aceita]

  Exemplo:

	$python3 main.py luc2.txt aab
