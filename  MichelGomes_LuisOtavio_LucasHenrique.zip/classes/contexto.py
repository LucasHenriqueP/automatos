class Contexto:
    def __init__(self, entrada, estadoAtual):
        self.entrada = entrada
        self.estadoAtual = estadoAtual
        pass
